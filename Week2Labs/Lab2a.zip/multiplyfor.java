//Tito Rivera trivera26@toromail.csudh.edu
public class multiplyfor {

    public static void main (String[] args) {

        for(int x=5; x < 55; x+=5){

            System.out.println(x);

            if(x > 50)break;

        }

    }

}