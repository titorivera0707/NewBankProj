//Tito Rivera trivera26@toromail.csudh.edu
public class multiply5 {

    public static void main (String[] args) {

        int x = 5;
        do{

            System.out.println(x);

            x += 5;

        }while(x < 55);

    }

}